"""
YAWE JAYDEN JOHN
S26B38/009
STRUCTURED PROGRAMMING-Python 
"""

DATA_FILE = "litres.txt"
REPORT_FILE = "station_report.txt"
QUIET_LIMIT = 400


def load_litres(filename):
    """Read daily litre totals from a text file and return them as a list."""
    litres = []
    try:
        with open(filename, "r") as file:
            for line in file:
                line = line.strip()
                if line == "":
                    continue  # skip blank lines
                try:
                    litres.append(int(line))
                except ValueError:
                    print("Skipping invalid line:", line)
    except FileNotFoundError:
        print("Dataset not found:", filename)
        return []
    return litres


def total_sales(litres):
    """Return the sum of all daily totals (0 if the list is empty)."""
    if len(litres) == 0:
        return 0
    total = 0
    for amount in litres:
        total += amount
    return total


def quiet_days(litres, limit=400):
    """Return how many days had sales strictly below the limit."""
    count = 0
    for amount in litres:
        if amount < limit:
            count += 1
    return count


def build_report(litres):
    """Build the summary as a list of text lines."""
    days = len(litres)
    total = total_sales(litres)
    average = total / days
    busiest = max(litres)
    quiet = quiet_days(litres, QUIET_LIMIT)

    lines = [
        "===== FUEL STATION SUMMARY =====",
        f"{'Days recorded:':<19}{days}",
        f"{'Total litres:':<19}{total}",
        f"{'Average per day:':<19}{average:.1f}",
        f"{'Busiest day:':<19}{busiest} litres",
        f"{'Quiet days (<' + str(QUIET_LIMIT) + '):':<19}{quiet}",
    ]
    return lines


def save_report(lines, filename):
    """Write the report lines to a file using mode 'w'."""
    with open(filename, "w") as file:
        for line in lines:
            file.write(line + "\n")
    print("Report saved to", filename)


def main():
    litres = load_litres(DATA_FILE)

    if len(litres) == 0:
        print("No data to analyse.")
        return

    report = build_report(litres)

    # Part C - screen report
    for line in report:
        print(line)

    # Part D - save to file
    save_report(report, REPORT_FILE)


main()


